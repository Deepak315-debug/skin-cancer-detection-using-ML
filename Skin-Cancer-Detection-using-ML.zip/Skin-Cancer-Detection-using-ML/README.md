1. Go to file my_model.keras with the extension of .ipynb (my_model.keras.ipynb)
2. Go to block 19, the epochs was initialised to 1, that's why the model was trained by whole data set only once.
3. If the epochs is initialised to 100, then the model will get trained by whole data set for 100 times.
4. If the epochs is iniatialised to some value which is of above 70 then the model will be trained by data set correctly, without any overfit. which can give accurate answer.
5. The block number 20 will give accurate graph if the model is trained by initialising epochs more than 70.
